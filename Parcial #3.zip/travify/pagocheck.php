<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$tituloPagina = "Pago realizado | Travify";
include 'includes/header.php';
?>

<section class="pago-hero">
  <div class="pago-hero-box">
    <h1>PAGO REALIZADO</h1>
    <p>Su confirmación será enviada por correo lo antes posible.</p>
  </div>
</section>

<!-- FORMULARIO -->
<section class="pago-section">
  <div class="pago-container">

    <div class="pago-box">

      <div class="pago-header">
        <h2>Gracias por preferir Travify</h2>
        <a href="pagos.php" class="btn">Reservar nuevamente</a>
      </div>

    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>