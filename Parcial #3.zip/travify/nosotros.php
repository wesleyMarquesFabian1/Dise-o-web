<?php
$tituloPagina = "Nosotros | Travify";
include 'includes/header.php';
?>

    <!-- hero 2 del home nosotros -->

    <section class="hero2">

        <div class="hero2-nosotros">
            <img src="recursos/nosotros hero.png">
        </div>

        <div class="hero2-nosotros">
            <div class="hero2-nosotros active">
                <div class="hero2noosotros-content">
                    <h1>SOMOS <span>TRAVIFY</span></h1>
                    <p>Creamos experiencias de viaje seguras, memorables y bien planificadas, conectando a cada viajero con destinos únicos dentro y fuera del país.</p>
                    <a href="paquetes.php" class="btn">RESERVAR</a>
                </div>
            </div>
        </div>

    </section>

    <!-- SERVICIOS DE PRIMERA -->

    <section class="servicios-section">
        <div class="servicios-titulo">
            <h1>NOSOTROS <span>| CONOCENOS</span></h1>
        </div>

        <div class="servicios-container">

            <div class="servicios-card">
                <img class="servicios-icon" src="recursos/innosotros.png">
                <div class="servicios-info">
                    <h2>MISIÓN</h2>
                    <p>Brindar experiencias de viaje seguras, accesibles y memorables, conectando a cada cliente con destinos y servicios adaptados a sus necesidades.</p>
                </div>
            </div>

            <div class="servicios-card">
                <img class="servicios-icon" src="recursos/innosotros2.png">
                <div class="servicios-info">
                    <h2>VISIÓN</h2>
                    <p>Ser una agencia de viajes reconocida por su confianza, innovación y excelencia en la planificación de experiencias turísticas.</p>
                </div>
            </div>

            <div class="servicios-card">
                <img class="servicios-icon" src="recursos/innosotros3.png">
                <div class="servicios-info">
                    <h2>VALORES</h2>
                    <p>Compromiso, responsabilidad, cercanía y pasión por el servicio, guiando cada experiencia con atención humana y calidad.</p>
                </div>
            </div>

            <div class="servicios-card">
                <img class="servicios-icon" src="recursos/innosotros4.png">
                <div class="servicios-info">
                    <h2>¿POR QUÉ ELEGIRNOS?</h2>
                    <p>Ofrecemos asesoría personalizada, variedad de destinos y acompañamiento continuo para que cada viaje sea confiable y bien organizado.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- testimonios -->

    <section class="testimonios-section">
        <div class="servicios-titulo">
            <h1>TRAVIFY EN CIFRAS</h1>
            <p>Descubre el alcance de nuestra experiencia y el compromiso con cada viajero que confía en nosotros.</p>
        </div>

        <div class="nosotroscard-container">

            <div class="nosotros-card">
                <div class="nosotros-info">
                    <h1>+<h2 class="contador" data-target="500">0</h2></h1>
                    <p>Viajeros atendidos con experiencias planificadas de forma segura y personalizada.</p>
                </div>
            </div>

            <div class="nosotros-card">
                <div class="nosotros-info">
                    <h1>+<h2 class="contador" data-target="100">0</h2></h1>
                    <p>Destinos nacionales e internacionales disponibles para distintos tipos de viajeros.</p>
                </div>
            </div>

            <div class="nosotros-card">
                <div class="nosotros-info">
                    <h1>+<h2 class="contador" data-target="150">0</h2></h1>
                    <p>Reservas gestionadas con organización, acompañamiento y atención oportuna.</p>
                </div>
            </div>
        </div>

    </section>

    <script>
        const counters = document.querySelectorAll('.contador');

        counters.forEach(counter => {

            const updateCounter = () => {
                const target = +counter.getAttribute('data-target');
                const current = +counter.innerText;

                const increment = target / 120;

                if (current < target) {
                    counter.innerText = Math.ceil(current + increment);
                    setTimeout(updateCounter, 20);
                } else {
                    counter.innerText = target;
                }
            };

            updateCounter();
        });
    </script>

<?php include 'includes/footer.php'; ?>