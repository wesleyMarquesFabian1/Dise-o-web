/*
const slides = document.querySelectorAll(".slide");
const nextBtn = document.getElementById("nextSlide");
const prevBtn = document.getElementById("prevSlide");
const dotsContainer = document.getElementById("dots");

let current = 0;
let autoSlide;


slides.forEach((_, index) => {
  const dot = document.createElement("button");
  dot.classList.add("dot");
  if (index === 0) dot.classList.add("active");

  dot.addEventListener("click", () => {
    goToSlide(index);
    resetAutoSlide();
  });

  dotsContainer.appendChild(dot);
});

const dots = document.querySelectorAll(".dot");

/* ===== Mostrar slide ===== *
function showSlide(index) {
  slides.forEach(slide => slide.classList.remove("active"));
  dots.forEach(dot => dot.classList.remove("active"));

  slides[index].classList.add("active");
  dots[index].classList.add("active");
}

/* ===== Ir a slide específico ===== *
function goToSlide(index) {
  current = index;
  showSlide(current);
}

/* ===== Siguiente ===== *
function nextSlide() {
  current = (current + 1) % slides.length;
  showSlide(current);
}

/* ===== Anterior ===== *
function prevSlide() {
  current = (current - 1 + slides.length) % slides.length;
  showSlide(current);
}

/* ===== Auto Slide ===== *
function startAutoSlide() {
  autoSlide = setInterval(nextSlide, 5000);
}

function resetAutoSlide() {
  clearInterval(autoSlide);
  startAutoSlide();
}

/* ===== Eventos botones ===== *
nextBtn.addEventListener("click", () => {
  nextSlide();
  resetAutoSlide();
});

prevBtn.addEventListener("click", () => {
  prevSlide();
  resetAutoSlide();
});

/* ===== Inicializar ===== 
startAutoSlide();

document.addEventListener("DOMContentLoaded", () => {
  const track = document.getElementById("sliderTrack");
  if (!track) return;

  const cards = Array.from(track.querySelectorAll(".card"));
  if (cards.length === 0) return;

  
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduceMotion) return;

  // ===== Configuración =====
  const gapPx = getGap(track);     
  let speedMs = 2200;              
  let animMs = 650;                
  let timer = null;


  cards.forEach(card => {
    const clone = card.cloneNode(true);
    clone.setAttribute("data-clone", "true");
    track.appendChild(clone);
  });

  //ancho de una tarjeta
  let cardWidth = cards[0].getBoundingClientRect().width;
  let step = cardWidth + gapPx;

  
  let index = 0;

  
  track.style.willChange = "transform";
  track.style.transition = `transform ${animMs}ms ease`;
  track.style.transform = "translateX(0px)";

  function next() {
    index += 1;
    track.style.transition = `transform ${animMs}ms ease`;
    track.style.transform = `translateX(-${index * step}px)`;


    if (index >= cards.length) {
      
      window.setTimeout(() => {
        track.style.transition = "none";
        index = 0;
        track.style.transform = "translateX(0px)";

        
        track.offsetHeight; 
        track.style.transition = `transform ${animMs}ms ease`;
      }, animMs + 10);
    }
  }

  function start() {
    stop();
    timer = setInterval(next, speedMs);
  }

  function stop() {
    if (timer) clearInterval(timer);
    timer = null;
  }


  function recalc() {
    cardWidth = cards[0].getBoundingClientRect().width;
    step = cardWidth + gapPx;

    track.style.transition = "none";
    track.style.transform = `translateX(-${index * step}px)`;
    track.offsetHeight;
    track.style.transition = `transform ${animMs}ms ease`;
  }

 
  track.addEventListener("mouseenter", stop);
  track.addEventListener("mouseleave", start);

  window.addEventListener("resize", () => {
    recalc();
  });

  start();

 
  function getGap(el) {
    const styles = window.getComputedStyle(el);
    const gap = styles.gap || styles.columnGap || "0px";
    return parseFloat(gap) || 0;
  }
});



/* ===== SLIDER OFERTAS ===== 

const ofertasTrack = document.getElementById("ofertasTrack");
const ofertasNext = document.getElementById("ofertasNext");
const ofertasPrev = document.getElementById("ofertasPrev");

let ofertasIndex = 0;
const ofertasCards = document.querySelectorAll(".ofertas-card");
const cardWidth = 300; 
let ofertasAuto;

/* Mostrar slide 
function moveOfertas() {
  ofertasTrack.style.transform = `translateX(-${ofertasIndex * cardWidth}px)`;

  if (ofertasIndex >= ofertasCards.length / 2) {
    setTimeout(() => {
      ofertasTrack.style.transition = "none";
      ofertasIndex = 0;
      ofertasTrack.style.transform = `translateX(0px)`;
    }, 500);

    setTimeout(() => {
      ofertasTrack.style.transition = "transform 0.5s ease";
    }, 600);
  }
}

/* Siguiente 
function nextOfertas() {
  ofertasIndex++;
  moveOfertas();
}

/* Anterior 
function prevOfertas() {
  if (ofertasIndex > 0) {
    ofertasIndex--;
    moveOfertas();
  }
}

/* Auto 
function startOfertasAuto() {
  ofertasAuto = setInterval(nextOfertas, 3000);
}

function resetOfertasAuto() {
  clearInterval(ofertasAuto);
  startOfertasAuto();
}

/* Eventos 
ofertasNext.addEventListener("click", () => {
  nextOfertas();
  resetOfertasAuto();
});

ofertasPrev.addEventListener("click", () => {
  prevOfertas();
  resetOfertasAuto();
});

/* Iniciar 
startOfertasAuto();

document.addEventListener("DOMContentLoaded", () => {

  const dropdowns = document.querySelectorAll(".dropdown-box");

  dropdowns.forEach(dropdown => {

    const placeholder = dropdown.querySelector(".dropdown-placeholder");
    const options = dropdown.querySelectorAll(".season-option");

    dropdown.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdown.classList.toggle("active");
    });

    options.forEach(option => {
      option.addEventListener("click", (e) => {
        e.stopPropagation();

        placeholder.textContent = option.dataset.value;

        dropdown.classList.remove("active");
      });
    });

  });

  document.addEventListener("click", () => {
    document.querySelectorAll(".dropdown-box")
      .forEach(d => d.classList.remove("active"));
  });

});*/

/* TESTIMONIOS*/
/* 
document.addEventListener("DOMContentLoaded", () => {
  const track = document.getElementById("testimoniosTrack");
  if (!track) return;

  const originalCards = Array.from(track.children);
  if (!originalCards.length) return;

  // Clonar tarjetas al final para el efecto infinito
  originalCards.forEach(card => {
    const clone = card.cloneNode(true);
    clone.setAttribute("aria-hidden", "true");
    track.appendChild(clone);
  });

  let index = 0;
  let interval;
  let step = 0;

  function getGap() {
    const styles = window.getComputedStyle(track);
    return parseFloat(styles.gap) || 0;
  }

  function updateStep() {
    const firstCard = track.querySelector(".testimonios-card");
    if (!firstCard) return;
    step = firstCard.offsetWidth + getGap();
  }

  function moveSlider() {
    index++;
    track.style.transition = "transform 0.5s ease";
    track.style.transform = `translateX(-${index * step}px)`;

    if (index >= originalCards.length) {
      setTimeout(() => {
        track.style.transition = "none";
        index = 0;
        track.style.transform = "translateX(0)";
      }, 650);
    }
  }

  function startSlider() {
    interval = setInterval(moveSlider, 1800);
  }

  function stopSlider() {
    clearInterval(interval);
  }

  updateStep();
  startSlider();

  track.addEventListener("mouseenter", stopSlider);
  track.addEventListener("mouseleave", startSlider);

  window.addEventListener("resize", () => {
    updateStep();
    track.style.transition = "none";
    track.style.transform = `translateX(-${index * step}px)`;
  });
});


*/

document.addEventListener("DOMContentLoaded", () => {
  /* =========================================================
     HERO PRINCIPAL
     ========================================================= */
  const hero = document.querySelector(".hero-slider");
  const slides = document.querySelectorAll(".hero-slider .slide");
  const nextBtn = document.getElementById("nextSlide");
  const prevBtn = document.getElementById("prevSlide");
  const dotsContainer = document.getElementById("dots");

  if (hero && slides.length && nextBtn && prevBtn && dotsContainer) {
    let current = 0;
    let autoSlide;

    // Crear dots solo si no existen aún
    if (!dotsContainer.children.length) {
      slides.forEach((_, index) => {
        const dot = document.createElement("button");
        dot.classList.add("dot");
        if (index === 0) dot.classList.add("active");

        dot.addEventListener("click", () => {
          goToSlide(index);
          resetAutoSlide();
        });

        dotsContainer.appendChild(dot);
      });
    }

    const dots = dotsContainer.querySelectorAll(".dot");

    function showSlide(index) {
      slides.forEach(slide => slide.classList.remove("active"));
      dots.forEach(dot => dot.classList.remove("active"));

      slides[index].classList.add("active");
      dots[index].classList.add("active");
    }

    function goToSlide(index) {
      current = index;
      showSlide(current);
    }

    function nextSlide() {
      current = (current + 1) % slides.length;
      showSlide(current);
    }

    function prevSlide() {
      current = (current - 1 + slides.length) % slides.length;
      showSlide(current);
    }

    function startAutoSlide() {
      autoSlide = setInterval(nextSlide, 5000);
    }

    function resetAutoSlide() {
      clearInterval(autoSlide);
      startAutoSlide();
    }

    nextBtn.addEventListener("click", () => {
      nextSlide();
      resetAutoSlide();
    });

    prevBtn.addEventListener("click", () => {
      prevSlide();
      resetAutoSlide();
    });

    startAutoSlide();
  }

  /* =========================================================
     DROPDOWNS PERSONALIZADOS
     ========================================================= */
  const dropdowns = document.querySelectorAll(".dropdown-box");

  dropdowns.forEach(dropdown => {
    const placeholder = dropdown.querySelector(".dropdown-placeholder");
    const options = dropdown.querySelectorAll(".season-option");

    dropdown.addEventListener("click", (e) => {
      e.stopPropagation();

      // Cierra los otros dropdowns
      dropdowns.forEach(d => {
        if (d !== dropdown) d.classList.remove("active");
      });

      dropdown.classList.toggle("active");
    });

    options.forEach(option => {
      option.addEventListener("click", (e) => {
        e.stopPropagation();
        if (placeholder) {
          placeholder.textContent = option.dataset.value;
        }
        dropdown.classList.remove("active");
      });
    });
  });

  document.addEventListener("click", () => {
    dropdowns.forEach(d => d.classList.remove("active"));
  });

  /* =========================================================
     SLIDER DESTINOS DESTACADOS
     ========================================================= */
  const destinosTrack = document.getElementById("sliderTrack");

  if (destinosTrack) {
    const cards = Array.from(destinosTrack.querySelectorAll(".card"));
    if (cards.length) {
      const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

      if (!reduceMotion) {
        cards.forEach(card => {
          const clone = card.cloneNode(true);
          clone.setAttribute("data-clone", "true");
          destinosTrack.appendChild(clone);
        });

        let index = 0;
        let timer = null;
        let step = 0;

        function getGap(el) {
          const styles = window.getComputedStyle(el);
          return parseFloat(styles.gap || styles.columnGap || "0") || 0;
        }

        function updateStep() {
          const firstCard = destinosTrack.querySelector(".card");
          if (!firstCard) return;
          step = firstCard.getBoundingClientRect().width + getGap(destinosTrack);
        }

        function next() {
          index += 1;
          destinosTrack.style.transition = "transform 0.65s ease";
          destinosTrack.style.transform = `translateX(-${index * step}px)`;

          if (index >= cards.length) {
            setTimeout(() => {
              destinosTrack.style.transition = "none";
              index = 0;
              destinosTrack.style.transform = "translateX(0px)";
              destinosTrack.offsetHeight;
            }, 660);
          }
        }

        function start() {
          stop();
          setTimeout(() => {
          next();
          timer = setInterval(next, 1200);
          }, 100);
        }

        function stop() {
          if (timer) clearInterval(timer);
          timer = null;
        }

        updateStep();
        start();

        destinosTrack.addEventListener("mouseenter", stop);
        destinosTrack.addEventListener("mouseleave", start);

        window.addEventListener("resize", () => {
          updateStep();
          destinosTrack.style.transition = "none";
          destinosTrack.style.transform = `translateX(-${index * step}px)`;
        });
      }
    }
  }

  /* =========================================================
     SLIDERS DE OFERTAS
     FUNCIONA EN HOME Y EN PAQUETES
     ========================================================= */
  const ofertasSliders = document.querySelectorAll(".ofertas-slider");

  ofertasSliders.forEach(slider => {
    const track = slider.querySelector(".ofertas-track");
    const next = slider.querySelector(".ofertas-arrow.next");
    const prev = slider.querySelector(".ofertas-arrow.prev");

    if (!track || !next || !prev) return;

    const originalCards = Array.from(track.querySelectorAll(".ofertas-card"));
    if (!originalCards.length) return;

    // Clonado para loop infinito
    originalCards.forEach(card => {
      const clone = card.cloneNode(true);
      clone.setAttribute("aria-hidden", "true");
      track.appendChild(clone);
    });

    let index = 0;
    let auto = null;
    let step = 0;

    function getGap() {
      const styles = window.getComputedStyle(track);
      return parseFloat(styles.gap || "0") || 0;
    }

    function updateStep() {
      const firstCard = track.querySelector(".ofertas-card");
      if (!firstCard) return;
      step = firstCard.offsetWidth + getGap();
    }

    function moveSlider() {
      track.style.transition = "transform 0.5s ease";
      track.style.transform = `translateX(-${index * step}px)`;

      if (index >= originalCards.length) {
        setTimeout(() => {
          track.style.transition = "none";
          index = 0;
          track.style.transform = "translateX(0)";
          track.offsetHeight;
        }, 550);
      }
    }

    function nextSlide() {
      index++;
      moveSlider();
    }

    function prevSlide() {
      if (index > 0) {
        index--;
        track.style.transition = "transform 0.5s ease";
        track.style.transform = `translateX(-${index * step}px)`;
      } else {
        index = originalCards.length - 1;
        track.style.transition = "none";
        track.style.transform = `translateX(-${index * step}px)`;
        track.offsetHeight;
        track.style.transition = "transform 0.5s ease";
      }
    }

    function startAuto() {
      stopAuto();
      setTimeout(() => {
        nextSlide();
        auto = setInterval(nextSlide, 3000);
      }, 100);
    }

    function stopAuto() {
      if (auto) clearInterval(auto);
    }

    next.addEventListener("click", () => {
      nextSlide();
      startAuto();
    });

    prev.addEventListener("click", () => {
      prevSlide();
      startAuto();
    });

    slider.addEventListener("mouseenter", stopAuto);
    slider.addEventListener("mouseleave", startAuto);

    window.addEventListener("resize", () => {
      updateStep();
      track.style.transition = "none";
      track.style.transform = `translateX(-${index * step}px)`;
    });

    updateStep();
    startAuto();
  });

  /* =========================================================
     TESTIMONIOS
     ========================================================= */
  const testimoniosTrack = document.getElementById("testimoniosTrack");

  if (testimoniosTrack) {
    const originalCards = Array.from(testimoniosTrack.children);

    if (originalCards.length) {
      originalCards.forEach(card => {
        const clone = card.cloneNode(true);
        clone.setAttribute("aria-hidden", "true");
        testimoniosTrack.appendChild(clone);
      });

      let index = 0;
      let interval = null;
      let step = 0;

      function getGap() {
        const styles = window.getComputedStyle(testimoniosTrack);
        return parseFloat(styles.gap || "0") || 0;
      }

      function updateStep() {
        const firstCard = testimoniosTrack.querySelector(".testimonios-card");
        if (!firstCard) return;
        step = firstCard.offsetWidth + getGap();
      }

      function moveSlider() {
        index++;
        testimoniosTrack.style.transition = "transform 0.5s ease";
        testimoniosTrack.style.transform = `translateX(-${index * step}px)`;

        if (index >= originalCards.length) {
          setTimeout(() => {
            testimoniosTrack.style.transition = "none";
            index = 0;
            testimoniosTrack.style.transform = "translateX(0)";
            testimoniosTrack.offsetHeight;
          }, 650);
        }
      }

      function startSlider() {
        stopSlider();
        interval = setInterval(moveSlider, 1800);
      }

      function stopSlider() {
        if (interval) clearInterval(interval);
      }

      updateStep();
      startSlider();

      testimoniosTrack.addEventListener("mouseenter", stopSlider);
      testimoniosTrack.addEventListener("mouseleave", startSlider);

      window.addEventListener("resize", () => {
        updateStep();
        testimoniosTrack.style.transition = "none";
        testimoniosTrack.style.transform = `translateX(-${index * step}px)`;
      });
    }
  }
});


  /* =========================================================
     PAGOS
     ========================================================= */

document.addEventListener("DOMContentLoaded", () => {
  const continenteSelect = document.getElementById("continente");
  const destinoSelect = document.getElementById("destino");
  const precioInput = document.getElementById("precio");
  const pagoForm = document.getElementById("pagoForm");
  const pagoSuccess = document.getElementById("pagoSuccess");
  const resumenPago = document.getElementById("resumenPago");

  if (!continenteSelect || !destinoSelect || !precioInput || !pagoForm) return;

  const destinosPorContinente = {
    america: [
      { nombre: "Samaná", precio: "$1,286" },
      { nombre: "Medellín", precio: "$1,286" },
      { nombre: "Pedernales", precio: "$1,286" },
      { nombre: "Nueva York", precio: "$2,400" },
      { nombre: "Cancún", precio: "$1,950" },
      { nombre: "Buenos Aires", precio: "$2,100" },
      { nombre: "Lima", precio: "$1,850" },
      { nombre: "Toronto", precio: "$2,500" }
    ],
    caribe: [
      { nombre: "Punta Cana", precio: "$1,300" },
      { nombre: "Aruba", precio: "$1,900" },
      { nombre: "Curazao", precio: "$1,850" },
      { nombre: "Jamaica", precio: "$1,980" },
      { nombre: "La Habana", precio: "$1,500" },
      { nombre: "San Juan", precio: "$1,750" },
      { nombre: "Bahamas", precio: "$2,200" },
      { nombre: "Martinica", precio: "$2,050" }
    ],
    europa: [
      { nombre: "París", precio: "$2,800" },
      { nombre: "Roma", precio: "$2,500" },
      { nombre: "Santorini", precio: "$3,200" },
      { nombre: "Barcelona", precio: "$2,400" },
      { nombre: "Ámsterdam", precio: "$2,100" },
      { nombre: "Lisboa", precio: "$1,900" },
      { nombre: "Praga", precio: "$2,000" },
      { nombre: "Viena", precio: "$2,300" }
    ],
    asia: [
      { nombre: "Tokio", precio: "$3,200" },
      { nombre: "Bali", precio: "$2,800" },
      { nombre: "Bangkok", precio: "$2,400" },
      { nombre: "Maldivas", precio: "$4,500" },
      { nombre: "Dubái", precio: "$2,900" },
      { nombre: "Phuket", precio: "$2,100" },
      { nombre: "Kyoto", precio: "$3,500" },
      { nombre: "Singapur", precio: "$3,100" }
    ],
    africa: [
      { nombre: "Marrakech", precio: "$1,800" },
      { nombre: "Zanzíbar", precio: "$2,600" },
      { nombre: "Safari Kenia", precio: "$3,800" },
      { nombre: "El Cairo", precio: "$2,200" },
      { nombre: "Ciudad del Cabo", precio: "$2,700" },
      { nombre: "Tanzania", precio: "$4,200" },
      { nombre: "Seychelles", precio: "$3,900" },
      { nombre: "Túnez", precio: "$1,500" }
    ]
  };

  continenteSelect.addEventListener("change", () => {
    const continente = continenteSelect.value;
    destinoSelect.innerHTML = '<option value="">Selecciona un destino</option>';
    precioInput.value = "";

    if (destinosPorContinente[continente]) {
      destinosPorContinente[continente].forEach(destino => {
        const option = document.createElement("option");
        option.value = destino.nombre;
        option.textContent = destino.nombre;
        option.dataset.precio = destino.precio;
        destinoSelect.appendChild(option);
      });
    }
  });

  destinoSelect.addEventListener("change", () => {
    const selectedOption = destinoSelect.options[destinoSelect.selectedIndex];
    precioInput.value = selectedOption.dataset.precio || "";
  });

  pagoForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const destino = destinoSelect.value;
    const precio = precioInput.value;

    resumenPago.textContent = `Tu pago fue realizado correctamente para el destino ${destino}, con un monto de ${precio}.`;

    pagoSuccess.style.display = "block";
    pagoForm.reset();
    destinoSelect.innerHTML = '<option value="">Primero selecciona un continente</option>';
    precioInput.value = "";

    pagoSuccess.scrollIntoView({
      behavior: "smooth",
      block: "center"
    });
  });
});