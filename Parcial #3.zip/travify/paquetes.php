<?php
$tituloPagina = "Pagos | Travify";
include 'includes/header.php';
?>


  <!-- DESTINOS MUNDIALES-->

    <section class="destinos-section">
        <div class="destinos-box">
            <h1 class="titulo-destinos2">NUESTROS DESTINOS</h1>
        </div>

        <!-- continentes botones -->
        <div class="tabs-continentes">
            <a href="#america" class="tab-continentes">AMERICA</a>
            <a href="#america" class="tab-continentes">EL CARIBE</a>
            <a href="#europa" class="tab-continentes">EUROPA</a>
            <a href="#asia" class="tab-continentes">ASIA</a>
            <a href="#africa" class="tab-continentes">AFRICA</a>
        </div>
    </section>    

   <!-- SEARCH BOX -->
  <section class="search-section2">
    <div class="search-box">

      <!-- Tabs -->
      <div class="tabs">
        <a href="#america" class="nav2-btn">TOURS</a>
        <a href="#europa" class="nav2-btn">MONUMENTOS</a>
        <a href="#africa" class="nav2-btn">AVENTURAS</a>
      </div>

      <!-- Inputs -->
        <div class="search-form">
                <!-- Caja de temporadas recomendadas -->
        <div class="input-box dropdown-box" id="seasonBox">
          <div class="text-group">
            <span class="dropdown-label">Temporadas recomendadas</span>
            <span class="dropdown-placeholder" id="seasonSelected">Conoce la temporada de tu próximo destino</span>
          </div>
          <span class="arrow">&#9662;</span>

          <!-- Menú desplegable -->
          <div class="season-dropdown" id="seasonDropdown">
            <div class="season-option" data-value="Europa: Invierno (noviembre a enero)">
              <strong>Europa</strong>
              <small><i class="fa-solid fa-calendar"></i> Invierno · noviembre a enero</small>
            </div>

            <div class="season-option" data-value="Caribe: Primavera/Verano (marzo a agosto)">
              <strong>Caribe</strong>
              <small><i class="fa-solid fa-calendar"></i> Marzo a agosto</small>
            </div>

            <div class="season-option" data-value="Asia: Otoño/Primavera (octubre a marzo)">
              <strong>Asia</strong>
              <small><i class="fa-solid fa-calendar"></i> Octubre a marzo</small>
            </div>

            <div class="season-option" data-value="Sudamérica: Primavera (septiembre a noviembre)">
              <strong>Sudamérica</strong>
              <small><i class="fa-solid fa-calendar"></i> Septiembre a noviembre</small>
            </div>
          </div>
        </div>

        <div class="input-box dropdown-box" id="tourismBox">
          <div class="text-group">
            <span class="dropdown-label">Tipos de turismos disponibles</span>
            <span class="dropdown-placeholder" id="tourismSelected">
              Selecciona un plan
            </span>
          </div>

          <span class="arrow">&#9662;</span>

          <div class="season-dropdown">

            <div class="season-option" data-value="Turismo cultural">
              <strong><i class="fa-solid fa-monument"></i> Turismo cultural</strong>
              <small>Historia, gastronomía y museos</small>
            </div>

            <div class="season-option" data-value="Ecoturismo">
              <strong><i class="fa-solid fa-leaf"></i> Ecoturismo</strong>
              <small>Naturaleza y aventura</small>
            </div>

            <div class="season-option" data-value="Turismo extremo">
              <strong><i class="fa-solid fa-water"></i> Turismo extremo</strong>
              <small>Adrenalina y actividades intensas</small>
            </div>

          </div>

        </div>

        <a href="login.php" class="btn">RESERVAR</a>
      </div>

    </div>
  </section>

    <!-- ULTIMAS OFERTAS -->

    <section class="ofertas-section">

    <div id="america" class="ofertas-titulo">
        <h1>ÚLTIMAS OFERTAS</h1>
    </div>

    <div class="ofertas-slider">

        <button class="ofertas-arrow prev" id="ofertasPrev"></button>
        <button class="ofertas-arrow next" id="ofertasNext"></button>

        <div class="ofertas-track" id="ofertasTrack">

        <!-- CARD 1 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/samana.jpg" alt="Samaná">
            <span class="ofertas-btn">OFERTAS LOCALES</span>
            </div>

            <div class="card-body">
            <h3>Samaná</h3>
            <p class="subtitulo">Naturaleza y aventura</p>

            <ul class="card-info">
                <li>Las Galeras • Las Terrenas</li>
                <li><i class="fa-solid fa-people-group"></i> Familia | 4 personas</li>
                <li><i class="fa-solid fa-clock"></i> 3 días | 2 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$1,286</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 2 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/medellin.jpg" alt="Medellin">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Medellin</h3>
            <p class="subtitulo">Ciudad urbana</p>

            <ul class="card-info">
                <li>El Poblado • Laureles</li>
                <li><i class="fa-solid fa-user-friends"></i> Pareja | 2 personas</li>
                <li><i class="fa-solid fa-plane"></i> Vuelo incluido</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$1,286</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 3 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/pedernales.jpg" alt="Pedernales">
            <span class="ofertas-btn">OFERTA LOCALES</span>
            </div>

            <div class="card-body">
            <h3>Pedernales</h3>
            <p class="subtitulo">Naturaleza virgen</p>

            <ul class="card-info">
                <li>Cabo Rojo • Bahía de las Águilas</li>
                <li><i class="fa-solid fa-people-group"></i> Familia | 5 personas</li>
                <li><i class="fa-solid fa-hotel"></i> Eco-lodge incluido</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$1,286</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 4 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/londres.jpg" alt="Londres">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Londres</h3>
            <p class="subtitulo">Museos y arquitectura</p>

            <ul class="card-info">
                <li>Westminster • Camden</li>
                <li><i class="fa-solid fa-user"></i> Por persona | 1 viajero</li>
                <li><i class="fa-solid fa-clock"></i> 5 días | 4 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$1,286</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 5 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/samana.jpg" alt="Samaná">
            <span class="ofertas-btn">OFERTAS LOCALES</span>
            </div>

            <div class="card-body">
            <h3>Samaná</h3>
            <p class="subtitulo">Naturaleza y aventura</p>

            <ul class="card-info">
                <li>Las Galeras • Las Terrenas</li>
                <li><i class="fa-solid fa-people-group"></i> Familia | 4 personas</li>
                <li><i class="fa-solid fa-clock"></i> 3 días | 2 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$1,286</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 6 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/medellin.jpg" alt="Medellin">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Medellin</h3>
            <p class="subtitulo">Ciudad urbana</p>

            <ul class="card-info">
                <li>El Poblado • Laureles</li>
                <li><i class="fa-solid fa-user-friends"></i> Pareja | 2 personas</li>
                <li><i class="fa-solid fa-plane"></i> Vuelo incluido</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$1,286</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 7 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/pedernales.jpg" alt="Pedernales">
            <span class="ofertas-btn">OFERTA LOCALES</span>
            </div>

            <div class="card-body">
            <h3>Pedernales</h3>
            <p class="subtitulo">Naturaleza virgen</p>

            <ul class="card-info">
                <li>Cabo Rojo • Bahía de las Águilas</li>
                <li><i class="fa-solid fa-people-group"></i> Familia | 5 personas</li>
                <li><i class="fa-solid fa-hotel"></i> Eco-lodge incluido</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$1,286</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 8 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/londres.jpg" alt="Londres">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Londres</h3>
            <p class="subtitulo">Museos y arquitectura</p>

            <ul class="card-info">
                <li>Westminster • Camden</li>
                <li><i class="fa-solid fa-user"></i> Por persona | 1 viajero</li>
                <li><i class="fa-solid fa-clock"></i> 5 días | 4 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$1,286</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        </div> <!-- cierre ofertas-track -->
    </div> <!-- cierre ofertas-slider -->

    </section>

    <!-- ASIA -->

    <section class="ofertas-section" id="asia">

    <div class="ofertas-titulo">
        <h1>DESTINOS | ASIA</h1>
    </div>

    <div class="ofertas-slider">

        <button class="ofertas-arrow prev" id="ofertasPrev"></button>
        <button class="ofertas-arrow next" id="ofertasNext"></button>

        <div class="ofertas-track" id="ofertasTrack">

        <!-- CARD 1 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/tokio.jfif" alt="Samaná">
            <span class="ofertas-btn">OFERTAS LOCALES</span>
            </div>

            <div class="card-body">
            <h3>Tokio</h3>
            <p class="subtitulo">Tecnología y tradición</p>

            <ul class="card-info">
                <li>Shibuya • Shinjuku</li>
                <li><i class="fa-solid fa-people-group"></i> Pareja | 2 personas</li>
                <li><i class="fa-solid fa-clock"></i> Vuelo incluido</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$3,200</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 2 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/bali.jfif" alt="Medellin">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Bali</h3>
            <p class="subtitulo">Espiritualidad y naturaleza</p>

            <ul class="card-info">
                <li>Ubud • Seminyak</li>
                <li><i class="fa-solid fa-user-friends"></i>Familia | 4 personas</li>
                <li><i class="fa-solid fa-plane"></i>8 días | 7 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$2,800</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 3 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/bangkok.jfif" alt="Pedernales">
            <span class="ofertas-btn">OFERTA LOCALES</span>
            </div>

            <div class="card-body">
            <h3>Bangkok</h3>
            <p class="subtitulo">Templos y sabores</p>

            <ul class="card-info">
                <li>Sukhumvit • Chao Phraya</li>
                <li><i class="fa-solid fa-people-group"></i>Grupo | 6 personas</li>
                <li><i class="fa-solid fa-hotel"></i>7 días | 6 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$2,400</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 4 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/maldivas.jfif" alt="Londres">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Maldivas</h3>
            <p class="subtitulo">Paraíso oceánico</p>

            <ul class="card-info">
                <li>Malé • Atolón Norte</li>
                <li><i class="fa-solid fa-user"></i>Pareja | 2 personas</li>
                <li><i class="fa-solid fa-clock"></i>Overwater bungalow</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$4,500</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 5 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/dubai.webp" alt="Samaná">
            <span class="ofertas-btn">OFERTAS LOCALES</span>
            </div>

            <div class="card-body">
            <h3>Dubái</h3>
            <p class="subtitulo">Lujo y modernidad</p>

            <ul class="card-info">
                <li>Marina • Old Dubai</li>
                <li><i class="fa-solid fa-people-group"></i>Por persona | 1 viajero</li>
                <li><i class="fa-solid fa-clock"></i>5 días | 4 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$2,900</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 6 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/phuket.jpg" alt="Medellin">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Phuket</h3>
            <p class="subtitulo">Playas y vida nocturna</p>

            <ul class="card-info">
                <li>Patong • Kata</li>
                <li><i class="fa-solid fa-user-friends"></i>Pareja | 2 personas</li>
                <li><i class="fa-solid fa-plane"></i>Vuelo incluido</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$2,100</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 7 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/kioto.webp" alt="Pedernales">
            <span class="ofertas-btn">OFERTA LOCALES</span>
            </div>

            <div class="card-body">
            <h3>Kyoto</h3>
            <p class="subtitulo">Cultura y templos zen</p>

            <ul class="card-info">
                <li>Gion • Arashiyama</li>
                <li><i class="fa-solid fa-people-group"></i>Familia | 4 personas</li>
                <li><i class="fa-solid fa-hotel"></i>6 días | 5 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$3,500</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 8 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/singapour.jpg" alt="Londres">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Singapur</h3>
            <p class="subtitulo">Ciudad del futuro</p>

            <ul class="card-info">
                <li>Marina Bay • Sentosa</li>
                <li><i class="fa-solid fa-user"></i>Grupo | 6 personas</li>
                <li><i class="fa-solid fa-clock"></i>5 días | 4 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$3,100</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        </div> <!-- cierre ofertas-track -->
    </div> <!-- cierre ofertas-slider -->

    </section>

    <!-- AFRICA -->

    <section class="ofertas-section" id="africa">

        <div class="ofertas-titulo">
            <h1>DESTINOS | AFRICA</h1>
        </div>

        <div class="ofertas-slider">

        <button class="ofertas-arrow prev" id="ofertasPrev"></button>
        <button class="ofertas-arrow next" id="ofertasNext"></button>

        <div class="ofertas-track" id="ofertasTrack">

        <!-- CARD 1 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/marrakech.jpg" alt="Samaná">
            <span class="ofertas-btn">OFERTAS LOCALES</span>
            </div>

            <div class="card-body">
            <h3>Marrakech</h3>
            <p class="subtitulo">Medinas y desierto</p>

            <ul class="card-info">
                <li>Medina • Majorelle</li>
                <li><i class="fa-solid fa-people-group"></i>Pareja | 2 personas</li>
                <li><i class="fa-solid fa-clock"></i>5 días | 4 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$1,800</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 2 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/zanzibar.jpeg" alt="Medellin">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Zanzíbar</h3>
            <p class="subtitulo">Playas y cultura swahili</p>

            <ul class="card-info">
                <li>Stone Town • Nungwi</li>
                <li><i class="fa-solid fa-user-friends"></i>Pareja | 2 personas</li>
                <li><i class="fa-solid fa-plane"></i>Vuelo incluido</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$2,600</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 3 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/kenia.jpg" alt="Pedernales">
            <span class="ofertas-btn">OFERTA LOCALES</span>
            </div>

            <div class="card-body">
            <h3>Safari Kenia</h3>
            <p class="subtitulo">Fauna salvaje</p>

            <ul class="card-info">
                <li>Masai Mara • Amboseli</li>
                <li><i class="fa-solid fa-people-group"></i>: Familia | 4 personas</li>
                <li><i class="fa-solid fa-hotel"></i>8 días | 7 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$3,800</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

<!-- CARD 4 -->
<div class="ofertas-card">
    <div class="card-img">
    <img src="recursos/el cairo.jfif" alt="El Cairo">
    <span class="ofertas-btn">OFERTA</span>
    </div>

    <div class="card-body">
    <h3>El Cairo</h3>
    <p class="subtitulo">Pirámides y misterio</p>

    <ul class="card-info">
        <li>Giza • Khan el-Khalili</li>
        <li><i class="fa-solid fa-user"></i> Por persona | 1 viajero</li>
        <li><i class="fa-solid fa-clock"></i> 6 días | 5 noches</li>
    </ul>

    <div class="card-footer">
        <div class="precio">
        <span>Desde</span>
        <strong>$2,200</strong>
        </div>
        <a href="login.php" class="nav2-btn">RESERVAR →</a>
    </div>
    </div>
</div>

<!-- CARD 5 -->
<div class="ofertas-card">
    <div class="card-img">
    <img src="recursos/ciudaddelcabo.webp" alt="Ciudad del Cabo">
    <span class="ofertas-btn">OFERTA</span>
    </div>

    <div class="card-body">
    <h3>Ciudad del Cabo</h3>
    <p class="subtitulo">Viñedos y ocean</p>

    <ul class="card-info">
        <li>Waterfront • Table Mountain</li>
        <li><i class="fa-solid fa-user-friends"></i> Pareja | 2 personas</li>
        <li><i class="fa-solid fa-clock"></i> 7 días | 6 noches</li>
    </ul>

    <div class="card-footer">
        <div class="precio">
        <span>Desde</span>
        <strong>$2,700</strong>
        </div>
        <a href="login.php" class="nav2-btn">RESERVAR →</a>
    </div>
    </div>
</div>

<!-- CARD 6 -->
<div class="ofertas-card">
    <div class="card-img">
    <img src="recursos/tanzania.jpg" alt="Tanzania">
    <span class="ofertas-btn">OFERTA</span>
    </div>

    <div class="card-body">
    <h3>Tanzania</h3>
    <p class="subtitulo">Serengeti y Kilimanjaro</p>

    <ul class="card-info">
        <li>Serengeti • Ngorongoro</li>
        <li><i class="fa-solid fa-people-group"></i> Grupo | 6 personas</li>
        <li><i class="fa-solid fa-plane"></i> Safari incluido</li>
    </ul>

    <div class="card-footer">
        <div class="precio">
        <span>Desde</span>
        <strong>$4,200</strong>
        </div>
        <a href="login.php" class="nav2-btn">RESERVAR →</a>
    </div>
    </div>
</div>

<!-- CARD 7 -->
<div class="ofertas-card">
    <div class="card-img">
    <img src="recursos/Seychelles.jpeg" alt="Seychelles">
    <span class="ofertas-btn">OFERTA</span>
    </div>

    <div class="card-body">
    <h3>Seychelles</h3>
    <p class="subtitulo">Playas cristalinas</p>

    <ul class="card-info">
        <li>Mahé • Praslin</li>
        <li><i class="fa-solid fa-user-friends"></i> Pareja | 2 personas</li>
        <li><i class="fa-solid fa-plane"></i> Vuelo incluido</li>
    </ul>

    <div class="card-footer">
        <div class="precio">
        <span>Desde</span>
        <strong>$3,900</strong>
        </div>
        <a href="login.php" class="nav2-btn">RESERVAR →</a>
    </div>
    </div>
</div>

<!-- CARD 8 -->
<div class="ofertas-card">
    <div class="card-img">
    <img src="recursos/tunez.jpg" alt="Túnez">
    <span class="ofertas-btn">OFERTA</span>
    </div>

    <div class="card-body">
    <h3>Túnez</h3>
    <p class="subtitulo">Historia romana y playas</p>

    <ul class="card-info">
        <li>Túnez Ciudad • Hammamet</li>
        <li><i class="fa-solid fa-people-group"></i> Familia | 4 personas</li>
        <li><i class="fa-solid fa-clock"></i> 5 días | 4 noches</li>
    </ul>

    <div class="card-footer">
        <div class="precio">
        <span>Desde</span>
        <strong>$1,500</strong>
        </div>
        <a href="login.php" class="nav2-btn">RESERVAR →</a>
    </div>
    </div>
</div>

            </div> <!-- cierre ofertas-track -->
        </div> <!-- cierre ofertas-slider -->

    </section>


    <!-- EUROPA -->

    <section class="ofertas-section" id="europa">

    <div class="ofertas-titulo">
        <h1>DESTINOS | EUROPA</h1>
    </div>

    <div class="ofertas-slider">

        <button class="ofertas-arrow prev" id="ofertasPrev"></button>
        <button class="ofertas-arrow next" id="ofertasNext"></button>

        <div class="ofertas-track" id="ofertasTrack">

        <!-- CARD 1 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/paris.webp" alt="París">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>París</h3>
            <p class="subtitulo">Moda y cultura</p>

            <ul class="card-info">
                <li>Montmartre • Le Marais</li>
                <li><i class="fa-solid fa-user-friends"></i> Pareja | 2 personas</li>
                <li><i class="fa-solid fa-clock"></i> 5 días | 4 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$2,800</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 2 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/roma.jfif" alt="Roma">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Roma</h3>
            <p class="subtitulo">Historia y gastronomía</p>

            <ul class="card-info">
                <li>Coliseo • Trastevere</li>
                <li><i class="fa-solid fa-people-group"></i> Familia | 4 personas</li>
                <li><i class="fa-solid fa-clock"></i> 6 días | 5 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$2,500</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 3 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/santorini.jfif" alt="Santorini">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Santorini</h3>
            <p class="subtitulo">Islas griegas</p>

            <ul class="card-info">
                <li>Oia • Fira</li>
                <li><i class="fa-solid fa-user-friends"></i> Pareja | 2 personas</li>
                <li><i class="fa-solid fa-plane"></i> Vuelo incluido</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$3,200</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 4 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/barcelona.jfif" alt="Barcelona">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Barcelona</h3>
            <p class="subtitulo">Gaudi y playa</p>

            <ul class="card-info">
                <li>Gràcia • Barceloneta</li>
                <li><i class="fa-solid fa-people-group"></i> Grupo | 6 personas</li>
                <li><i class="fa-solid fa-clock"></i> 5 días | 4 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$2,400</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 5 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/amsterdam.jpg" alt="Ámsterdam">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Ámsterdam</h3>
            <p class="subtitulo">Canales y arte</p>

            <ul class="card-info">
                <li>Jordaan • Museumplein</li>
                <li><i class="fa-solid fa-user-friends"></i> Pareja | 2 personas</li>
                <li><i class="fa-solid fa-clock"></i> 4 días | 3 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$2,100</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 6 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/lisboa.jpg" alt="Lisboa">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Lisboa</h3>
            <p class="subtitulo">Fado y pastel de nata</p>

            <ul class="card-info">
                <li>Alfama • Belém</li>
                <li><i class="fa-solid fa-user"></i> Por persona | 1 viajero</li>
                <li><i class="fa-solid fa-clock"></i> 5 días | 4 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$1,900</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 7 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/praga.jpeg" alt="Praga">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Praga</h3>
            <p class="subtitulo">Ciudad de las torres</p>

            <ul class="card-info">
                <li>Ciudad Vieja • Malá Strana</li>
                <li><i class="fa-solid fa-people-group"></i> Familia | 4 personas</li>
                <li><i class="fa-solid fa-clock"></i> 6 días | 5 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$2,000</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        <!-- CARD 8 -->
        <div class="ofertas-card">
            <div class="card-img">
            <img src="recursos/viena.jpg" alt="Viena">
            <span class="ofertas-btn">OFERTA</span>
            </div>

            <div class="card-body">
            <h3>Viena</h3>
            <p class="subtitulo">Música y palacios</p>

            <ul class="card-info">
                <li>Innere Stadt • Schönbrunn</li>
                <li><i class="fa-solid fa-user-friends"></i> Pareja | 2 personas</li>
                <li><i class="fa-solid fa-clock"></i> 5 días | 4 noches</li>
            </ul>

            <div class="card-footer">
                <div class="precio">
                <span>Desde</span>
                <strong>$2,300</strong>
                </div>
                <a href="login.php" class="nav2-btn">RESERVAR →</a>
            </div>
            </div>
        </div>

        </div> <!-- cierre ofertas-track -->
    </div> <!-- cierre ofertas-slider -->

<?php include 'includes/footer.php'; ?>