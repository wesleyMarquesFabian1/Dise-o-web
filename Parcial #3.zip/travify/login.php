<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
$tituloPagina = "Login | Travify";

include 'includes/conexion.php';

$mensajeError = "";


if (isset($_SESSION['usuario_id'])) {
    header("Location: pagos.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $correo = trim($_POST['usuario'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($correo === '' || $password === '') {
        $mensajeError = "Debes completar todos los campos.";
    } elseif (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $mensajeError = "Debes ingresar un correo electrónico válido.";
    } else {
        $stmt = $conn->prepare("SELECT id, nombre, correo, clave FROM usuarios WHERE correo = ?");
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows === 1) {
            $usuario = $resultado->fetch_assoc();

            if (password_verify($password, $usuario['clave'])) {
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_nombre'] = $usuario['nombre'];
                $_SESSION['usuario_correo'] = $usuario['correo'];

                header("Location: pagos.php");
                exit;
            } else {
                $mensajeError = "Contraseña incorrecta.";
            }
        } else {
            $mensajeError = "No existe una cuenta con ese correo.";
        }

        $stmt->close();
    }
}

include 'includes/header.php';
?>

<section class="login-section">
  <div class="login-container">

    <div class="login-image">
      <img src="recursos/login team.png" alt="Travify login">
    </div>

    <div class="login-box">

      <h2>INICIAR SESION</h2>
      <p class="login-subtext">
        Accede a tu cuenta para continuar con tu reserva.
      </p>

      <?php if ($mensajeError !== ''): ?>
        <div class="pago-error" style="display:block; margin-bottom:20px;">
          <p><?php echo htmlspecialchars($mensajeError); ?></p>
        </div>
      <?php endif; ?>

      <form class="login-form" action="login.php" method="POST">

        <input
          type="email"
          name="usuario"
          placeholder="Correo electrónico"
          required
          value="<?php echo isset($_POST['usuario']) ? htmlspecialchars($_POST['usuario']) : ''; ?>"
        >

        <input
          type="password"
          name="password"
          placeholder="Contraseña"
          required
        >

        <button type="submit" class="login-btn">
          Iniciar sesión
        </button>

      </form>

      <div class="login-register">
        <p>¿No tienes una cuenta?</p>
        <a href="registro.php" class="register-link">
          Crear usuario
        </a>
      </div>

    </div>

  </div>
</section>

<?php include 'includes/footer.php'; ?>