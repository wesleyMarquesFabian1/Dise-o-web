<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($tituloPagina)) {
    $tituloPagina = "Travify";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title><?php echo htmlspecialchars($tituloPagina); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>

  <!-- NAVBAR -->
  <header class="navbar">
    <div class="nav-container">
      <div class="logo">
        <a href="index.php">
          <img src="recursos/logo travify.png" alt="Travify">
        </a>
      </div>

      <nav class="menu">
        <a href="index.php">INICIO</a>
        <a href="paquetes.php">PAQUETES</a>
        <a href="nosotros.php">NOSOTROS</a>
        <a href="contactos.php">CONTACTOS</a>
      </nav>

      <?php if (isset($_SESSION['usuario_id'])): ?>
        <a href="logout.php" class="btn">SALIR</a>
      <?php else: ?>
        <a href="login.php" class="btn">LOGIN</a>
      <?php endif; ?>
    </div>
  </header>