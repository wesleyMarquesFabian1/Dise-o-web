    <!-- footer -->

    <footer class="footer-section">
      <div class="footer-container">

        <div class="footer-col1">
          <div class="footer-redes">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-whatsapp"></i></a>
          </div>

          <div class="footer-infocol1">
            <h5><i class="fa-solid fa-envelope"></i> CORREO RD</h5>
            <p>info@travify.com</p>
          </div>

          <div class="footer-infocol1">
            <h5><i class="fa-solid fa-plane"></i> CORREO INTERNACIONAL</h5>
            <p>internacional@travify.com</p>
          </div>

          <div class="footer-logos">
            <img src="recursos/logo travify blanco.png" alt="Logo Travify">
          </div>
        </div>

        <div class="footer-col2">
          <div class="footer-infocol2">
            <h3>TRAVIFY</h3>
            <p>Agencia de viajes especializada en experiencias únicas, destinos inolvidables y paquetes diseñados para cada tipo de viajero.</p>
            <a href="nosotros.php" class="btn">CONOCENOS</a>
            <p>© 2026 Travify. Todos los derechos reservados.</p>
          </div>
        </div>

        <div class="footer-col3">
          <div class="footer-infocol3">
            <h3>CONTACTO Y SOPORTE</h3>
            <p><i class="fas fa-phone"></i> +1 (809) 555-1234</p>
            <h4><i class="far fa-clock"></i> HORARIOS</h4>
            <p>Lunes a Viernes: 9:00 AM | 6:00 PM</p>
            <p>Sábados: 9:00 AM | 1:00 PM</p>
            <a href="contactos.php" class="btn">CONTACTANOS</a>
          </div>
        </div>

      </div>
    </footer>

    <script src="main.js"></script>
  </body>
</html>