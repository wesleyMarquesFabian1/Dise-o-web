<?php
$tituloPagina = "Contactos | Travify";
include 'includes/header.php';
?>

<?php
include 'includes/conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $asunto = $_POST['asunto'];
    $mensaje = $_POST['mensaje'];

    $sql = "INSERT INTO contactos (nombre, correo, asunto, mensaje)
            VALUES ('$nombre', '$correo', '$asunto', '$mensaje')";

    if ($conn->query($sql) === TRUE) {
        $mensajeExito = "Mensaje enviado correctamente";
    } else {
        $mensajeError = "Error: " . $conn->error;
    }
}
?>

  <section class="contactos-section">
    <div class="contactos-titulo">
        <h1>CONTACTANOS</h1>
        <p>Descubre por qué cientos de viajeros confían en Travify para planificar sus aventuras.</p>
      </div>

    
    <div class="contacto-container">

    <!-- COLUMNA IMAGEN -->
    <div class="contacto-imagen">
      <img src="recursos/contactosmap.jpeg" alt="Imagen de contacto">
    </div>

    <!-- COLUMNA FORMULARIO -->
    <div class="contacto-formulario">
      <h2>Contáctanos</h2>

      <form action="contactos.php" method="POST">

        <div class="form-grupo">
          <input type="text" name="nombre" placeholder="Nombre completo" required>
        </div>

        <div class="form-grupo">
          <input type="email" name="correo" placeholder="Correo electrónico" required>
        </div>

        <div class="form-grupo">
          <input type="text" name="asunto" placeholder="Asunto" required>
        </div>

        <div class="form-grupo">
          <textarea name="mensaje" rows="4" placeholder="Mensaje" required></textarea>
        </div>

        <button type="submit" class="btn-enviar">Enviar mensaje</button>

        <?php if (isset($mensajeExito)): ?>
          <p style="color: green; margin-top: 10px;">
            <?php echo $mensajeExito; ?>
          </p>
        <?php endif; ?>

       <?php if (isset($mensajeError)): ?>
            <p style="color: red; margin-top: 10px;">
              <?php echo $mensajeError; ?>
            </p>
        <?php endif; ?>
      </form>

    </div>

  </div>
    <div class="mapa">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3785.201475186965!2d-69.67362222498912!3d18.42915918264678!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8ea57ffe58becf01%3A0x2330a397d4421897!2sAeropuerto%20Internacional%20Las%20Am%C3%A9ricas!5e0!3m2!1ses-419!2sdo!4v1771858599727!5m2!1ses-419!2sdo" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>

    

  </section>

<?php include 'includes/footer.php'; ?>