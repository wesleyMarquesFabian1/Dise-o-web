<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$tituloPagina = "Pagos | Travify";
include 'includes/conexion.php';

// DESTINOS
$destinosPorContinente = [
    "america_caribe" => [
        "Samaná" => 1286.00,
        "Medellín" => 1286.00,
        "Pedernales" => 1286.00
    ],
    "asia" => [
        "Tokio" => 3200.00,
        "Bali" => 2800.00,
        "Bangkok" => 2400.00,
        "Maldivas" => 4500.00,
        "Dubái" => 2900.00,
        "Phuket" => 2100.00,
        "Kyoto" => 3500.00,
        "Singapur" => 3100.00
    ],
    "africa" => [
        "Marrakech" => 1800.00,
        "Zanzíbar" => 2600.00,
        "Safari Kenia" => 3800.00,
        "El Cairo" => 2200.00,
        "Ciudad del Cabo" => 2700.00,
        "Tanzania" => 4200.00,
        "Seychelles" => 3900.00,
        "Túnez" => 1500.00
    ],
    "europa" => [
        "París" => 2800.00,
        "Roma" => 2500.00,
        "Santorini" => 3200.00,
        "Barcelona" => 2400.00,
        "Ámsterdam" => 2100.00,
        "Lisboa" => 1900.00,
        "Praga" => 2000.00,
        "Viena" => 2300.00
    ]
];

$mensajeError = "";

// PROCESAR PAGO
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $continente = trim($_POST['continente'] ?? '');
    $destino = trim($_POST['destino'] ?? '');
    $titular = trim($_POST['titular'] ?? '');
    $numero_tarjeta = trim($_POST['numero_tarjeta'] ?? '');
    $fecha_expiracion = trim($_POST['fecha_expiracion'] ?? '');
    $cvv = trim($_POST['cvv'] ?? '');

    if (
        $continente === '' ||
        $destino === '' ||
        $titular === '' ||
        $numero_tarjeta === '' ||
        $fecha_expiracion === '' ||
        $cvv === ''
    ) {
        $mensajeError = "Debes completar todos los campos.";
    } elseif (!isset($destinosPorContinente[$continente][$destino])) {
        $mensajeError = "Destino no válido.";
    } else {

        $precio = $destinosPorContinente[$continente][$destino];

        $numero_tarjeta = preg_replace('/\D/', '', $numero_tarjeta);
        $ultimos_4 = substr($numero_tarjeta, -4);

        $estado_pago = "Pagado";
        $fecha_registro = date("Y-m-d H:i:s");

        $stmt = $conn->prepare("INSERT INTO pagos 
        (continente, destino, precio, titular, ultimos_4, fecha_expiracion, estado_pago, fecha_registro) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

        if ($stmt) {
            $stmt->bind_param(
                "ssdsssss",
                $continente,
                $destino,
                $precio,
                $titular,
                $ultimos_4,
                $fecha_expiracion,
                $estado_pago,
                $fecha_registro
            );

            if ($stmt->execute()) {
                header("Location: pagocheck.php");
                exit;
            } else {
                $mensajeError = "Error al guardar el pago: " . $stmt->error;
            }

            $stmt->close();
        } else {
            $mensajeError = "Error en la consulta: " . $conn->error;
        }
    }
}

include 'includes/header.php';
?>

<!-- HERO -->
<section class="pago-hero">
  <div class="pago-hero-box">
    <h1>PAGO SEGURO</h1>
    <p>Completa tu pago para confirmar tu reserva con Travify.</p>
  </div>
</section>

<!-- FORMULARIO -->
<section class="pago-section">
  <div class="pago-container">

    <div class="pago-image">
      <img src="recursos/pagos.png" alt="Pago Travify">
    </div>

    <div class="pago-box">

      <div class="pago-header">
        <h2>PAGO DE RESERVA</h2>
        <p>Selecciona tu destino y completa el pago.</p>
      </div>

      <?php if ($mensajeError !== ''): ?>
        <div class="pago-error" style="max-width:500px;margin:20px auto;">
          <h3>Error</h3>
          <p><?php echo htmlspecialchars($mensajeError); ?></p>
        </div>
      <?php endif; ?>

      <form class="pago-form" method="POST" action="">

        <label>Destino / Región</label>
        <select name="continente" id="continente" required>
          <option value="">Selecciona</option>
          <option value="america_caribe">América / Caribe</option>
          <option value="asia">Asia</option>
          <option value="africa">África</option>
          <option value="europa">Europa</option>
        </select>

        <label>Destino</label>
        <select name="destino" id="destino" required>
          <option value="">Selecciona una región</option>
        </select>

        <label>Precio</label>
        <input type="text" id="precio" readonly>

        <label>Titular</label>
        <input type="text" name="titular" required>

        <label>Número de tarjeta</label>
        <input type="text" name="numero_tarjeta" required>

        <div class="pago-row">
          <input type="text" name="fecha_expiracion" placeholder="MM/AA" required>
          <input type="password" name="cvv" placeholder="CVV" required>
        </div>

        <button type="submit" class="pago-btn">REALIZAR PAGO</button>

      </form>

    </div>
  </div>
</section>

<script>
document.addEventListener("DOMContentLoaded", () => {

  const continente = document.getElementById("continente");
  const destino = document.getElementById("destino");
  const precio = document.getElementById("precio");

  const datos = {
    america_caribe: [
      { nombre: "Samaná", precio: 1286 },
      { nombre: "Medellín", precio: 1286 },
      { nombre: "Pedernales", precio: 1286 }
    ],
    asia: [
      { nombre: "Tokio", precio: 3200 },
      { nombre: "Bali", precio: 2800 },
      { nombre: "Bangkok", precio: 2400 },
      { nombre: "Maldivas", precio: 4500 },
      { nombre: "Dubái", precio: 2900 },
      { nombre: "Phuket", precio: 2100 },
      { nombre: "Kyoto", precio: 3500 },
      { nombre: "Singapur", precio: 3100 }
    ],
    africa: [
      { nombre: "Marrakech", precio: 1800 },
      { nombre: "Zanzíbar", precio: 2600 },
      { nombre: "Safari Kenia", precio: 3800 },
      { nombre: "El Cairo", precio: 2200 },
      { nombre: "Ciudad del Cabo", precio: 2700 },
      { nombre: "Tanzania", precio: 4200 },
      { nombre: "Seychelles", precio: 3900 },
      { nombre: "Túnez", precio: 1500 }
    ],
    europa: [
      { nombre: "París", precio: 2800 },
      { nombre: "Roma", precio: 2500 },
      { nombre: "Santorini", precio: 3200 },
      { nombre: "Barcelona", precio: 2400 },
      { nombre: "Ámsterdam", precio: 2100 },
      { nombre: "Lisboa", precio: 1900 },
      { nombre: "Praga", precio: 2000 },
      { nombre: "Viena", precio: 2300 }
    ]
  };

  continente.addEventListener("change", () => {
    destino.innerHTML = '<option value="">Selecciona destino</option>';
    precio.value = "";

    if (datos[continente.value]) {
      datos[continente.value].forEach(d => {
        let op = document.createElement("option");
        op.value = d.nombre;
        op.textContent = d.nombre;
        op.dataset.precio = d.precio;
        destino.appendChild(op);
      });
    }
  });

  destino.addEventListener("change", () => {
    let sel = destino.options[destino.selectedIndex];
    precio.value = sel && sel.dataset.precio
      ? "$" + Number(sel.dataset.precio).toLocaleString("en-US")
      : "";
  });

});
</script>

<?php include 'includes/footer.php'; ?>