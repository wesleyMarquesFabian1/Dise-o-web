<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
$tituloPagina = "Registro | Travify";

include 'includes/conexion.php';

$mensajeError = "";
$mensajeExito = "";

// PROCESAR FORMULARIO
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nombre = trim($_POST['nombre'] ?? '');
    $correo = trim($_POST['correo'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $confirmar_password = trim($_POST['confirmar_password'] ?? '');

    // VALIDACIONES
    if (
        $nombre === '' ||
        $correo === '' ||
        $password === '' ||
        $confirmar_password === ''
    ) {
        $mensajeError = "Debes completar todos los campos.";
    } elseif (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $mensajeError = "El correo electrónico no es válido.";
    } elseif ($password !== $confirmar_password) {
        $mensajeError = "Las contraseñas no coinciden.";
    } else {

        // VERIFICAR SI EL CORREO EXISTE
        $verificar = $conn->prepare("SELECT id FROM usuarios WHERE correo = ?");
        $verificar->bind_param("s", $correo);
        $verificar->execute();
        $resultado = $verificar->get_result();

        if ($resultado->num_rows > 0) {
            $mensajeError = "Ese correo ya está registrado.";
        } else {

            // ENCRIPTAR CONTRASEÑA
            $claveHash = password_hash($password, PASSWORD_DEFAULT);
            $fecha_registro = date("Y-m-d H:i:s");

            // INSERTAR USUARIO
            $stmt = $conn->prepare("INSERT INTO usuarios (nombre, correo, clave, fecha_registro) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $nombre, $correo, $claveHash, $fecha_registro);

            if ($stmt->execute()) {
                $mensajeExito = "Cuenta creada correctamente. Ya puedes iniciar sesión.";
            } else {
                $mensajeError = "Error al crear la cuenta: " . $stmt->error;
            }

            $stmt->close();
        }

        $verificar->close();
    }
}

include 'includes/header.php';
?>

<!-- REGISTRO -->
<section class="register-section">

    <div class="register-container">

        <!-- Imagen -->
        <div class="register-image">
            <img src="recursos/resgitro.png" alt="Registro Travify">
        </div>

        <!-- Formulario -->
        <div class="register-box">

            <div class="register-header">
                <h2>CREAR CUENTA</h2>
                <p>Crea tu cuenta para comenzar a planificar tus viajes con Travify.</p>
            </div>

            <!-- MENSAJES -->
            <?php if ($mensajeExito !== ''): ?>
                <div class="pago-success" style="display:block; margin-bottom:20px;">
                    <p><?php echo htmlspecialchars($mensajeExito); ?></p>
                </div>
            <?php endif; ?>

            <?php if ($mensajeError !== ''): ?>
                <div class="pago-error" style="display:block; margin-bottom:20px;">
                    <p><?php echo htmlspecialchars($mensajeError); ?></p>
                </div>
            <?php endif; ?>

            <!-- FORM -->
            <form class="register-form" action="registro.php" method="POST">

                <input
                    type="text"
                    name="nombre"
                    placeholder="Nombre completo"
                    required
                    value="<?php echo isset($_POST['nombre']) ? htmlspecialchars($_POST['nombre']) : ''; ?>"
                >

                <input
                    type="email"
                    name="correo"
                    placeholder="Correo electrónico"
                    required
                    value="<?php echo isset($_POST['correo']) ? htmlspecialchars($_POST['correo']) : ''; ?>"
                >

                <input
                    type="password"
                    name="password"
                    placeholder="Contraseña"
                    required
                >

                <input
                    type="password"
                    name="confirmar_password"
                    placeholder="Confirmar contraseña"
                    required
                >

                <button type="submit" class="register-btn">
                    Crear cuenta
                </button>

            </form>

            <!-- LOGIN -->
            <div class="register-login">
                <p>¿Ya tienes una cuenta?</p>
                <a href="login.php" class="login-link">
                    Iniciar sesión
                </a>
            </div>

        </div>

    </div>

</section>

<?php include 'includes/footer.php'; ?>