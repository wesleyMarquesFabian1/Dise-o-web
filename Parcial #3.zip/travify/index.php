<?php
$tituloPagina = "Inicio | Travify";
include 'includes/header.php';
?>

<!-- HERO PRINCIPAL -->
<section class="hero">
  <div class="hero-slider" id="heroSlider">

    <!-- Slide 1 -->
    <div class="slide active">
      <div class="hero-content">
        <h1>NUEVOS <span>DESTINOS</span></h1>
        <p>
          Explora destinos increíbles con Travify. Ofrecemos paquetes personalizados 
          que combinan comodidad, aventura y cultura.
        </p>
      </div>
    </div>

    <!-- Slide 2 -->
    <div class="slide">
      <div class="hero-content">
        <h1>VIAJA <span>FÁCIL</span></h1>
        <p>Organizamos tu viaje para que solo te preocupes por disfrutar.</p>
      </div>
    </div>

    <!-- Slide 3 -->
    <div class="slide">
      <div class="hero-content">
        <h1>TOURS <span>TOP</span></h1>
        <p>Descubre los destinos más populares al mejor precio.</p>
      </div>
    </div>

    <!-- Flechas -->
    <button class="slider-btn prev" id="prevSlide">‹</button>
    <button class="slider-btn next" id="nextSlide">›</button>

    <!-- Dots -->
    <div class="dots" id="dots"></div>

  </div>
</section>

  <!-- SEARCH BOX -->
  <section class="search-section">
    <div class="search-box">

      <!-- Tabs -->
      <div class="tabs">
        <a href="paquetes.php" class="nav2-btn">TOURS</a>
        <a href="paquetes.php" class="nav2-btn">MONUMENTOS</a>
        <a href="paquetes.php" class="nav2-btn">AVENTURAS</a>
      </div>

      <!-- Inputs -->
        <div class="search-form">
                <!-- Caja de temporadas recomendadas -->
        <div class="input-box dropdown-box" id="seasonBox">
          <div class="text-group">
            <span class="dropdown-label">Temporadas recomendadas</span>
            <span class="dropdown-placeholder" id="seasonSelected">Conoce la temporada de tu próximo destino</span>
          </div>
          <span class="arrow">&#9662;</span>

          <!-- Menú desplegable -->
          <div class="season-dropdown" id="seasonDropdown">
            <div class="season-option" data-value="Europa: Invierno (noviembre a enero)">
              <strong>Europa</strong>
              <small><i class="fa-solid fa-calendar"></i> Invierno · noviembre a enero</small>
            </div>

            <div class="season-option" data-value="Caribe: Primavera/Verano (marzo a agosto)">
              <strong>Caribe</strong>
              <small><i class="fa-solid fa-calendar"></i> Marzo a agosto</small>
            </div>

            <div class="season-option" data-value="Asia: Otoño/Primavera (octubre a marzo)">
              <strong>Asia</strong>
              <small><i class="fa-solid fa-calendar"></i> Octubre a marzo</small>
            </div>

            <div class="season-option" data-value="Sudamérica: Primavera (septiembre a noviembre)">
              <strong>Sudamérica</strong>
              <small><i class="fa-solid fa-calendar"></i> Septiembre a noviembre</small>
            </div>
          </div>
        </div>

        <div class="input-box dropdown-box" id="tourismBox">
          <div class="text-group">
            <span class="dropdown-label">Tipos de turismos disponibles</span>
            <span class="dropdown-placeholder" id="tourismSelected">
              Selecciona un plan
            </span>
          </div>

          <span class="arrow">&#9662;</span>

          <div class="season-dropdown">

            <div class="season-option" data-value="Turismo cultural">
              <strong><i class="fa-solid fa-monument"></i> Turismo cultural</strong>
              <small>Historia, gastronomía y museos</small>
            </div>

            <div class="season-option" data-value="Ecoturismo">
              <strong><i class="fa-solid fa-leaf"></i> Ecoturismo</strong>
              <small>Naturaleza y aventura</small>
            </div>

            <div class="season-option" data-value="Turismo extremo">
              <strong><i class="fa-solid fa-water"></i> Turismo extremo</strong>
              <small>Adrenalina y actividades intensas</small>
            </div>

          </div>

        </div>

        <a href="paquetes.php" class="btn">RESERVAR</a>
      </div>

    </div>
  </section>

  <!-- DESTINOS DESTACADOS -->

  <section class="destacados-section">
    <div class="destacados-box">
      <h1 class="titulo-destinos">DESTINOS DESTACADOS</h1>
    </div>

    <!-- continentes botones -->
      <div class="tabs-continentes">
        <a href="paquetes.php #america" class="tab-continentes">AMERICA</a>
        <a href="paquetes.php #america" class="tab-continentes">EL CARIBE</a>
        <a href="paquetes.php #europa" class="tab-continentes">EUROPA</a>
        <a href="paquetes.php #asia" class="tab-continentes">ASIA</a>
        <a href="paquetes.php #africa" class="tab-continentes">AFRICA</a>
      </div>

    <section class="slider-section">

      <div class="slider">
        <div class="slider-track" id="sliderTrack">

          <div class="card">
            <img src="recursos/zimbabue.jpg">
            <h3><i class="fa-solid fa-location-dot"></i> Zimbabue</h3>
            <p>Naturaleza y aventura</p>
            <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
          </div>

          <div class="card">
            <img src="recursos/dubai.jpg">
            <h3><i class="fa-solid fa-location-dot"></i> Dubái, EAU</h3>
            <p>Tradición y modernidad</p>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
          </div>

          <div class="card">
            <img src="recursos/islandia.jpg">
            <h3><i class="fa-solid fa-location-dot"></i> Islandia</h3>
            <p>Fuego y hielo</p>
            <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
          </div>

          <div class="card">
            <img src="recursos/tulum.jpg">
            <h3><i class="fa-solid fa-location-dot"></i> Tulum MX</h3>
            <p>Playa y cultura</p>
            <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
          </div>

          <div class="card">
            <img src="recursos/sao paulo.jpg">
            <h3><i class="fa-solid fa-location-dot"></i> Sao Paulo</h3>
            <p>Energía urbana</p>
            <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
          </div>

          <div class="card">
            <img src="recursos/portadaplaya.jpg">
            <h3><i class="fa-solid fa-location-dot"></i> Punta Cana</h3>
            <p>Paraíso caribeño</p>
            <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
          </div>

          <div class="card">
            <img src="recursos/mallorca.jpg">
            <h3><i class="fa-solid fa-location-dot"></i> Mallorca</h3>
            <p>Encanto mediterráneo</p>
            <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
          </div>

          <div class="card">
            <img src="recursos/copenhage.jpg">
            <h3><i class="fa-solid fa-location-dot"></i> Copenhague</h3>
            <p>Paisajes y monumentos</p>
            <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
              <i class="fa-solid fa-star"></i>
          </div>

        </div>
      </div>

    </section>

    <!-- SERVICIOS DE PRIMERA -->

    <section class="servicios-section">
      <div class="servicios-titulo">
        <h1>SERVICIOS DE PRIMERA</h1>
      </div>

      <div class="servicios-container">

        <div class="servicios-card">
          <img class="servicios-icon" src="recursos/icon servis 1.png">
          <div class="servicios-info">
            <h2>MEJORES PRECIOS</h2>
            <p>Tarifas competitivas y ofertas exclusivas. Garantizamos el mejor precio en cada paquete.</p>
          </div>
        </div>

        <div class="servicios-card">
          <img class="servicios-icon" src="recursos/icon servis 2.png">
          <div class="servicios-info">
            <h2>SERVICIOS VARIADOS</h2>
            <p>Accede a los mejores destinos de República Dominicana y el mundo.</p>
          </div>
        </div>

        <div class="servicios-card">
          <img class="servicios-icon2" src="recursos/icon servis 3.png">
          <div class="servicios-info2">
            <h2>CALIDAD GARANTIZADA</h2>
            <p>Trabajamos con hoteles y operadores certificados. Tu experiencia de viaje está asegurada con nosotros.</p>
          </div>
        </div>

        <div class="servicios-card">
          <img class="servicios-icon" src="recursos/icon servis 4.png">
          <div class="servicios-info">
            <h2>ATENCION PERSONALIZADA</h2>
            <p>Asesoría experta disponible 24/7. Diseñamos tu viaje según tus necesidades y preferencias.</p>
          </div>
        </div>

      </div>

    </section>

    <!-- ULTIMAS OFERTAS -->

<section class="ofertas-section">

  <div class="ofertas-titulo">
    <h1>ÚLTIMAS OFERTAS</h1>
  </div>

  <div class="ofertas-slider">

    <button class="ofertas-arrow prev" id="ofertasPrev"></button>
    <button class="ofertas-arrow next" id="ofertasNext"></button>

    <div class="ofertas-track" id="ofertasTrack">

      <!-- CARD 1 -->
      <div class="ofertas-card">
        <div class="card-img">
          <img src="recursos/samana.jpg" alt="Samaná">
          <span class="ofertas-btn">OFERTAS LOCALES</span>
        </div>

        <div class="card-body">
          <h3>Samaná</h3>
          <p class="subtitulo">Naturaleza y aventura</p>

          <ul class="card-info">
            <li>Las Galeras • Las Terrenas</li>
            <li><i class="fa-solid fa-people-group"></i> Familia | 4 personas</li>
            <li><i class="fa-solid fa-clock"></i> 3 días | 2 noches</li>
          </ul>

          <div class="card-footer">
            <div class="precio">
              <span>Desde</span>
              <strong>$1,286</strong>
            </div>
            <a href="login.php" class="nav2-btn">RESERVAR →</a>
          </div>
        </div>
      </div>

      <!-- CARD 2 -->
      <div class="ofertas-card">
        <div class="card-img">
          <img src="recursos/medellin.jpg" alt="Medellin">
          <span class="ofertas-btn">OFERTA</span>
        </div>

        <div class="card-body">
          <h3>Medellin</h3>
          <p class="subtitulo">Ciudad urbana</p>

          <ul class="card-info">
            <li>El Poblado • Laureles</li>
            <li><i class="fa-solid fa-user-friends"></i> Pareja | 2 personas</li>
            <li><i class="fa-solid fa-plane"></i> Vuelo incluido</li>
          </ul>

          <div class="card-footer">
            <div class="precio">
              <span>Desde</span>
              <strong>$1,286</strong>
            </div>
            <a href="login.php" class="nav2-btn">RESERVAR →</a>
          </div>
        </div>
      </div>

      <!-- CARD 3 -->
      <div class="ofertas-card">
        <div class="card-img">
          <img src="recursos/pedernales.jpg" alt="Pedernales">
          <span class="ofertas-btn">OFERTA LOCALES</span>
        </div>

        <div class="card-body">
          <h3>Pedernales</h3>
          <p class="subtitulo">Naturaleza virgen</p>

          <ul class="card-info">
            <li>Cabo Rojo • Bahía de las Águilas</li>
            <li><i class="fa-solid fa-people-group"></i> Familia | 5 personas</li>
            <li><i class="fa-solid fa-hotel"></i> Eco-lodge incluido</li>
          </ul>

          <div class="card-footer">
            <div class="precio">
              <span>Desde</span>
              <strong>$1,286</strong>
            </div>
            <a href="login.php" class="nav2-btn">RESERVAR →</a>
          </div>
        </div>
      </div>

      <!-- CARD 4 -->
      <div class="ofertas-card">
        <div class="card-img">
          <img src="recursos/londres.jpg" alt="Londres">
          <span class="ofertas-btn">OFERTA</span>
        </div>

        <div class="card-body">
          <h3>Londres</h3>
          <p class="subtitulo">Museos y arquitectura</p>

          <ul class="card-info">
            <li>Westminster • Camden</li>
            <li><i class="fa-solid fa-user"></i> Por persona | 1 viajero</li>
            <li><i class="fa-solid fa-clock"></i> 5 días | 4 noches</li>
          </ul>

          <div class="card-footer">
            <div class="precio">
              <span>Desde</span>
              <strong>$1,286</strong>
            </div>
            <a href="login.php" class="nav2-btn">RESERVAR →</a>
          </div>
        </div>
      </div>

       <!-- CARD 1 -->
      <div class="ofertas-card">
        <div class="card-img">
          <img src="recursos/samana.jpg" alt="Samaná">
          <span class="ofertas-btn">OFERTAS LOCALES</span>
        </div>

        <div class="card-body">
          <h3>Samaná</h3>
          <p class="subtitulo">Naturaleza y aventura</p>

          <ul class="card-info">
            <li>Las Galeras • Las Terrenas</li>
            <li><i class="fa-solid fa-people-group"></i> Familia | 4 personas</li>
            <li><i class="fa-solid fa-clock"></i> 3 días | 2 noches</li>
          </ul>

          <div class="card-footer">
            <div class="precio">
              <span>Desde</span>
              <strong>$1,286</strong>
            </div>
            <a href="login.php" class="nav2-btn">RESERVAR →</a>
          </div>
        </div>
      </div>

      <!-- CARD 2 -->
      <div class="ofertas-card">
        <div class="card-img">
          <img src="recursos/medellin.jpg" alt="Medellin">
          <span class="ofertas-btn">OFERTA</span>
        </div>

        <div class="card-body">
          <h3>Medellin</h3>
          <p class="subtitulo">Ciudad urbana</p>

          <ul class="card-info">
            <li>El Poblado • Laureles</li>
            <li><i class="fa-solid fa-user-friends"></i> Pareja | 2 personas</li>
            <li><i class="fa-solid fa-plane"></i> Vuelo incluido</li>
          </ul>

          <div class="card-footer">
            <div class="precio">
              <span>Desde</span>
              <strong>$1,286</strong>
            </div>
            <a href="login.php" class="nav2-btn">RESERVAR →</a>
          </div>
        </div>
      </div>

      <!-- CARD 3 -->
      <div class="ofertas-card">
        <div class="card-img">
          <img src="recursos/pedernales.jpg" alt="Pedernales">
          <span class="ofertas-btn">OFERTA LOCALES</span>
        </div>

        <div class="card-body">
          <h3>Pedernales</h3>
          <p class="subtitulo">Naturaleza virgen</p>

          <ul class="card-info">
            <li>Cabo Rojo • Bahía de las Águilas</li>
            <li><i class="fa-solid fa-people-group"></i> Familia | 5 personas</li>
            <li><i class="fa-solid fa-hotel"></i> Eco-lodge incluido</li>
          </ul>

          <div class="card-footer">
            <div class="precio">
              <span>Desde</span>
              <strong>$1,286</strong>
            </div>
            <a href="login.php" class="nav2-btn">RESERVAR →</a>
          </div>
        </div>
      </div>

      <!-- CARD 4 -->
      <div class="ofertas-card">
        <div class="card-img">
          <img src="recursos/londres.jpg" alt="Londres">
          <span class="ofertas-btn">OFERTA</span>
        </div>

        <div class="card-body">
          <h3>Londres</h3>
          <p class="subtitulo">Museos y arquitectura</p>

          <ul class="card-info">
            <li>Westminster • Camden</li>
            <li><i class="fa-solid fa-user"></i> Por persona | 1 viajero</li>
            <li><i class="fa-solid fa-clock"></i> 5 días | 4 noches</li>
          </ul>

          <div class="card-footer">
            <div class="precio">
              <span>Desde</span>
              <strong>$1,286</strong>
            </div>
            <a href="login.php" class="nav2-btn">RESERVAR →</a>
          </div>
        </div>
      </div>

    </div> <!-- cierre ofertas-track -->
  </div> <!-- cierre ofertas-slider -->

</section>
  
 
<!-- hero 2 del home -->

<section class="hero2">

  <video class="hero2-video" autoplay muted loop playsinline>
    <source src="recursos/hero paris.mp4" type="video/mp4">
  </video>

  <div class="hero2-slider">
    <div class="hero2-slide active">
      <div class="hero2-content">
        <h1>PARÍS <span>FRANCIA</span></h1>
        <p>Recorre la Torre Eiffel, el río Sena y museos emblemáticos en una escapada inolvidable.</p>
        <a href="paquetes.php #europa" class="btn">conoce</a>
      </div>
    </div>
  </div>

</section>

<!-- testimonios -->

  <section class="testimonios-section">
    <div class="servicios-titulo">
      <h1>TESTIMONIOS</h1>
      <p>Descubre por qué cientos de viajeros confían en Travify para planificar sus aventuras.</p>
    </div>

    <div class="testimonios-slider">
      <div class="testimonios-container" id="testimoniosTrack">

        <div class="testimonios-card">
          <div class="testimonios-fts">
            <img class="testimonios-img" src="recursos/perfiltes1.png" alt="Emily Carter">
          </div>
          <div class="testimonios-info">
            <h2>EMILY CARTER</h2>
            <p>Todo fue claro y rápido. Mi viaje quedó organizado sin complicaciones.</p>
          </div>
        </div>

        <div class="testimonios-card">
          <div class="testimonios-fts">
            <img class="testimonios-img" src="recursos/perfiltes2.png" alt="Luca Moretti">
          </div>
          <div class="testimonios-info">
            <h2>LUCA MORETTI</h2>
            <p>Excelente atención y muy buenos precios. Volvería a reservar con ellos.</p>
          </div>
        </div>

        <div class="testimonios-card">
          <div class="testimonios-fts">
            <img class="testimonios-img" src="recursos/perfiltes3.png" alt="Sofia Dimitrova">
          </div>
          <div class="testimonios-info">
            <h2>SOFIA DIMITROVA</h2>
            <p>La experiencia fue cómoda y segura. Me encantó el trato recibido.</p>
          </div>
        </div>

        <div class="testimonios-card">
          <div class="testimonios-fts">
            <img class="testimonios-img" src="recursos/perfiltes4.png" alt="Mateo Alvarez">
          </div>
          <div class="testimonios-info">
            <h2>MATEO ALVAREZ</h2>
            <p>Reservar fue muy fácil y el paquete se ajustó perfecto a mi presupuesto.</p>
          </div>
        </div>

        <div class="testimonios-card">
          <div class="testimonios-fts">
            <img class="testimonios-img" src="recursos/perfiltes5.png" alt="Amina El Idrissi">
          </div>
          <div class="testimonios-info">
            <h2>AMINA EL IDRISSI</h2>
            <p>Muy buena organización desde el inicio. Todo salió tal como esperaba.</p>
          </div>
        </div>

        <div class="testimonios-card">
          <div class="testimonios-fts">
            <img class="testimonios-img" src="recursos/perfiltes6.png" alt="Noah Andersen">
          </div>
          <div class="testimonios-info">
            <h2>NOAH ANDERSEN</h2>
            <p>El servicio fue ágil y confiable. Me ayudaron en cada paso del viaje.</p>
          </div>
        </div>

      </div>
    </div>
  </section>

    <!-- colaboradores -->
      <section class="colaboradores-section">
        <div class="colaboradores-container">

          <div class="colaboradores-titulo">
            <h1>COLABORADORES</h1>
          </div>

          <div class="colaboradores-logos">
            <img src="recursos/banreservas-seeklogo.png">
            <img src="recursos/arajet.png">
            <img src="recursos/americanairlines.png">
            <img src="recursos/popular.png">
            <img src="recursos/Ministerio.png">
            <img src="recursos/gpuntacana.png">
          </div>


        </div>
      </section>

<?php include 'includes/footer.php'; ?>