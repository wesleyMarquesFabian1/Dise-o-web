-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 09-04-2026 a las 01:33:50
-- Versión del servidor: 8.4.7
-- Versión de PHP: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `travify`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contactos`
--

DROP TABLE IF EXISTS `contactos`;
CREATE TABLE IF NOT EXISTS `contactos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `correo` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asunto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mensaje` text COLLATE utf8mb4_unicode_ci,
  `fecha_envio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `contactos`
--

INSERT INTO `contactos` (`id`, `nombre`, `correo`, `asunto`, `mensaje`, `fecha_envio`) VALUES
(1, 'larimar', 'caraballo@hotmail.com', 'reserva', 'quiero saber la confirmacion', '2026-03-29 04:40:24'),
(2, 'larimar', 'caraballo@hotmail.com', 'reserva', 'quiero saber la confirmacion', '2026-03-29 04:41:31'),
(3, 'larimar', 'caraballo@hotmail.com', 'reserva', 'rt', '2026-03-29 04:41:39'),
(4, 'larimar', 'caraballo@hotmail.com', 'reserva', 'rt', '2026-03-29 04:42:41'),
(5, 'larimar', 'caraballo@hotmail.com', 'reserva', 'rttt', '2026-03-29 04:42:45'),
(6, 'larimar', 'caraballo@hotmail.com', 'reserva', 'rttt', '2026-03-29 04:43:15'),
(7, 'larimar', 'caraballo@hotmail.com', 'reserva', 'rttt', '2026-03-29 04:43:20'),
(8, 'larimar', 'caraballo@hotmail.com', 'reserva', 'rttt', '2026-03-29 04:47:54'),
(9, 'larimar', 'caraballo@hotmail.com', 'reserva', 'rttt', '2026-03-29 04:56:11'),
(10, 'larimar', 'caraballo@hotmail.com', 'reserva', 'rttttttt\r\n', '2026-03-29 05:01:59'),
(11, 'larimar', 'caraballo@hotmail.com', 'reserva', 'yyyyy', '2026-04-08 01:31:12'),
(12, 'larimar', 'caraballo@hotmail.com', 'reserva', 'yyyyy', '2026-04-08 01:53:25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

DROP TABLE IF EXISTS `pagos`;
CREATE TABLE IF NOT EXISTS `pagos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `continente` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destino` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `titular` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ultimos_4` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_expiracion` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado_pago` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_registro` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `pagos`
--

INSERT INTO `pagos` (`id`, `continente`, `destino`, `precio`, `titular`, `ultimos_4`, `fecha_expiracion`, `estado_pago`, `fecha_registro`) VALUES
(1, 'america', 'Medellín', 1286.00, 'Larimar', '2222', '0122', 'Pagado', '2026-04-08 07:34:27'),
(2, 'america', 'Medellín', 1286.00, 'Larimar', '2222', '0122', 'Pagado', '2026-04-08 07:38:45'),
(3, 'america', 'Medellín', 1286.00, 'Larimar', '2222', '0122', 'Pagado', '2026-04-08 07:39:27'),
(4, 'america', 'Medellín', 1286.00, 'Larimar', '2222', '0122', 'Pagado', '2026-04-08 07:39:36'),
(5, 'america', 'Medellín', 1286.00, 'Larimar', '2222', '0122', 'Pagado', '2026-04-08 07:40:03'),
(6, 'america', 'Medellín', 1286.00, 'Larimar', '2222', '0122', 'Pagado', '2026-04-08 07:40:09'),
(7, 'america', 'Medellín', 1286.00, 'Larimar', '2222', '0122', 'Pagado', '2026-04-08 07:45:40'),
(8, 'caribe', 'Punta Cana', 1300.00, 'Larimar', '2222', '0122', 'Pagado', '2026-04-08 07:45:56'),
(9, 'caribe', 'Punta Cana', 1300.00, 'Larimar', '2222', '0122', 'Pagado', '2026-04-08 07:46:10'),
(10, 'america', 'Medellín', 1286.00, 'Larimar', '2222', '0122', 'Pagado', '2026-04-08 07:46:18'),
(11, 'america_caribe', 'Samaná', 1286.00, 'Larimar', '2222', '1221', 'Pagado', '2026-04-08 08:35:14'),
(12, 'america_caribe', 'Medellín', 1286.00, 'Larimar', '2222', '1221', 'Pagado', '2026-04-08 08:51:33'),
(13, 'asia', 'Maldivas', 4500.00, 'Larimar', '2222', '1221', 'Pagado', '2026-04-09 03:35:27'),
(14, 'asia', 'Bangkok', 2400.00, 'Larimar', '2222', '1221', 'Pagado', '2026-04-09 05:27:34');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correo` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `clave` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_registro` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `correo`, `clave`, `fecha_registro`) VALUES
(1, 'larimar', 'caraballo@hotmail.com', '$2y$10$Q5Mah0a7xhy5dZHGCUATfuCbrubf2tUrW/Iy7D2ajk4il.GsC/j2i', '2026-04-09 00:21:24'),
(2, 'larimar', 'graciano@hotmail.com', '$2y$10$EkcVajaXxugY8wFrKSDc/OXrqlXwqDlaHuCTUVy8qsh/BXp77OlNi', '2026-04-09 01:29:07');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
