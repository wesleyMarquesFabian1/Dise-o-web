const slides = document.querySelectorAll(".slide");
const nextBtn = document.getElementById("nextSlide");
const prevBtn = document.getElementById("prevSlide");
const dotsContainer = document.getElementById("dots");

let current = 0;
let autoSlide;


slides.forEach((_, index) => {
  const dot = document.createElement("button");
  dot.classList.add("dot");
  if (index === 0) dot.classList.add("active");

  dot.addEventListener("click", () => {
    goToSlide(index);
    resetAutoSlide();
  });

  dotsContainer.appendChild(dot);
});

const dots = document.querySelectorAll(".dot");

/* ===== Mostrar slide ===== */
function showSlide(index) {
  slides.forEach(slide => slide.classList.remove("active"));
  dots.forEach(dot => dot.classList.remove("active"));

  slides[index].classList.add("active");
  dots[index].classList.add("active");
}

/* ===== Ir a slide específico ===== */
function goToSlide(index) {
  current = index;
  showSlide(current);
}

/* ===== Siguiente ===== */
function nextSlide() {
  current = (current + 1) % slides.length;
  showSlide(current);
}

/* ===== Anterior ===== */
function prevSlide() {
  current = (current - 1 + slides.length) % slides.length;
  showSlide(current);
}

/* ===== Auto Slide ===== */
function startAutoSlide() {
  autoSlide = setInterval(nextSlide, 5000);
}

function resetAutoSlide() {
  clearInterval(autoSlide);
  startAutoSlide();
}

/* ===== Eventos botones ===== */
nextBtn.addEventListener("click", () => {
  nextSlide();
  resetAutoSlide();
});

prevBtn.addEventListener("click", () => {
  prevSlide();
  resetAutoSlide();
});

/* ===== Inicializar ===== */
startAutoSlide();






document.addEventListener("DOMContentLoaded", () => {
  const track = document.getElementById("sliderTrack");
  if (!track) return;

  const cards = Array.from(track.querySelectorAll(".card"));
  if (cards.length === 0) return;

  
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduceMotion) return;

  // ===== Configuración =====
  const gapPx = getGap(track);     
  let speedMs = 2200;              
  let animMs = 650;                
  let timer = null;


  cards.forEach(card => {
    const clone = card.cloneNode(true);
    clone.setAttribute("data-clone", "true");
    track.appendChild(clone);
  });

  //ancho de una tarjeta
  let cardWidth = cards[0].getBoundingClientRect().width;
  let step = cardWidth + gapPx;

  
  let index = 0;

  
  track.style.willChange = "transform";
  track.style.transition = `transform ${animMs}ms ease`;
  track.style.transform = "translateX(0px)";

  function next() {
    index += 1;
    track.style.transition = `transform ${animMs}ms ease`;
    track.style.transform = `translateX(-${index * step}px)`;


    if (index >= cards.length) {
      
      window.setTimeout(() => {
        track.style.transition = "none";
        index = 0;
        track.style.transform = "translateX(0px)";

        
        track.offsetHeight; 
        track.style.transition = `transform ${animMs}ms ease`;
      }, animMs + 10);
    }
  }

  function start() {
    stop();
    timer = setInterval(next, speedMs);
  }

  function stop() {
    if (timer) clearInterval(timer);
    timer = null;
  }


  function recalc() {
    cardWidth = cards[0].getBoundingClientRect().width;
    step = cardWidth + gapPx;

    track.style.transition = "none";
    track.style.transform = `translateX(-${index * step}px)`;
    track.offsetHeight;
    track.style.transition = `transform ${animMs}ms ease`;
  }

 
  track.addEventListener("mouseenter", stop);
  track.addEventListener("mouseleave", start);

  window.addEventListener("resize", () => {
    recalc();
  });

  start();

 
  function getGap(el) {
    const styles = window.getComputedStyle(el);
    const gap = styles.gap || styles.columnGap || "0px";
    return parseFloat(gap) || 0;
  }
});




/* ===== SLIDER OFERTAS ===== */

const ofertasTrack = document.getElementById("ofertasTrack");
const ofertasNext = document.getElementById("ofertasNext");
const ofertasPrev = document.getElementById("ofertasPrev");

let ofertasIndex = 0;
const ofertasCards = document.querySelectorAll(".ofertas-card");
const cardWidth = 300; 
let ofertasAuto;

/* Mostrar slide */
function moveOfertas() {
  ofertasTrack.style.transform = `translateX(-${ofertasIndex * cardWidth}px)`;

  if (ofertasIndex >= ofertasCards.length / 2) {
    setTimeout(() => {
      ofertasTrack.style.transition = "none";
      ofertasIndex = 0;
      ofertasTrack.style.transform = `translateX(0px)`;
    }, 500);

    setTimeout(() => {
      ofertasTrack.style.transition = "transform 0.5s ease";
    }, 600);
  }
}

/* Siguiente */
function nextOfertas() {
  ofertasIndex++;
  moveOfertas();
}

/* Anterior */
function prevOfertas() {
  if (ofertasIndex > 0) {
    ofertasIndex--;
    moveOfertas();
  }
}

/* Auto */
function startOfertasAuto() {
  ofertasAuto = setInterval(nextOfertas, 3000);
}

function resetOfertasAuto() {
  clearInterval(ofertasAuto);
  startOfertasAuto();
}

/* Eventos */
ofertasNext.addEventListener("click", () => {
  nextOfertas();
  resetOfertasAuto();
});

ofertasPrev.addEventListener("click", () => {
  prevOfertas();
  resetOfertasAuto();
});

/* Iniciar */
startOfertasAuto();

